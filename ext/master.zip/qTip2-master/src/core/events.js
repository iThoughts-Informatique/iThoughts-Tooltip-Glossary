function showMethod(event) {
	if(this.tooltip.hasClass(disabledClass)) { return FALSE; }

	// Clear hide timers
	clearTimeout(this.timers.show);
	clearTimeout(this.timers.hide);

	// Start show timer
	var callback = $.proxy(function(){ this.toggle(TRUE, event); }, this);
	if(this.options.show.delay > 0) {
		this.timers.show = setTimeout(callback, this.options.show.delay);
	}
	else{ callback(); }
}

function hideMethod(event) {
	if(this.tooltip.hasClass(disabledClass)) { return FALSE; }

	// Check if new target was actually the tooltip element
	var relatedTarget = $(event.relatedTarget),
		ontoTooltip = relatedTarget.closest(selector)[0] === this.tooltip[0],
		ontoTarget = relatedTarget[0] === this.options.show.target[0];

	// Clear timers and stop animation queue
	clearTimeout(this.timers.show);
	clearTimeout(this.timers.hide);

	// Prevent hiding if tooltip is fixed and event target is the tooltip.
	// Or if mouse positioning is enabled and cursor momentarily overlaps
	if(this !== relatedTarget[0] && 
		(this.options.position.target === 'mouse' && ontoTooltip) || 
		(this.options.hide.fixed && (
			(/mouse(out|leave|move)/).test(event.type) && (ontoTooltip || ontoTarget))
		))
	{
		try {
			event.preventDefault();
			event.stopImmediatePropagation();
		} catch(e) {}

		return;
	}

	// If tooltip has displayed, start hide timer
	var callback = $.proxy(function(){ this.toggle(FALSE, event); }, this);
	if(this.options.hide.delay > 0) {
		this.timers.hide = setTimeout(callback, this.options.hide.delay);
	}
	else{ callback(); }
}

function inactiveMethod(event) {
	if(this.tooltip.hasClass(disabledClass)) { return FALSE; }

	// Clear timer
	clearTimeout(this.timers.inactive);
	this.timers.inactive = setTimeout(
		$.proxy(function(){ this.hide(event); }, this), this.options.hide.inactive
	);
}

function repositionMethod(event) {
	if(this.rendered && this.tooltip[0].offsetWidth > 0) { this.reposition(event); }
}

// Store mouse coordinates
PROTOTYPE._storeMouse = function(event) {
	this.mouse = {
		pageX: event.pageX,
		pageY: event.pageY,
		type: 'mousemove',
		scrollX: window.pageXOffset || document.body.scrollLeft || document.documentElement.scrollLeft,
		scrollY: window.pageYOffset || document.body.scrollTop || document.documentElement.scrollTop
	};
};

// Bind events
PROTOTYPE._bind = function(target, events, method, suffix) {
	var ns = '.' + this._id + (suffix || '');
	events.length && target.bind(
		(events.split ? events : events.join(ns + ' ')) + ns,
		$.proxy(method, this)
	);
};

// Event trigger
PROTOTYPE._trigger = function(type, args, event) {
	var callback = $.Event('tooltip'+type);
	callback.originalEvent = (event && $.extend({}, event)) || this.cache.event || NULL;

	this.triggering = TRUE;
	this.tooltip.trigger(callback, [this].concat(args || []));
	this.triggering = FALSE;

	return !callback.isDefaultPrevented();
};

// Event assignment method
PROTOTYPE._assignEvents = function() {
	var options = this.options,
		posOptions = options.position,

		tooltip = this.tooltip,
		showTarget = options.show.target,
		hideTarget = options.hide.target,
		containerTarget = posOptions.container,
		viewportTarget = posOptions.viewport,
		documentTarget = $(document),
		bodyTarget = $(document.body),
		windowTarget = $(window),

		showEvents = options.show.event ? $.trim('' + options.show.event).split(' ') : [],
		hideEvents = options.hide.event ? $.trim('' + options.hide.event).split(' ') : [],
		toggleEvents = [];

	// Focus/blur
	this._bind(tooltip, ['mouseenter', 'mouseleave'], function(event) {
		var state = event.type === 'mouseenter';

		// Focus the tooltip on mouseenter (z-index stacking)
		if(state) { this.focus(event); }

		// Add hover class
		tooltip.toggleClass(hoverClass, state);
	});

	// Hide tooltips when leaving current window/frame (but not select/option elements)
	if(/mouse(out|leave)/i.test(options.hide.event) && options.hide.leave === 'window') {
		this._bind(documentTarget, ['mouseout', 'blur'], function(event) {
			if(!/select|option/.test(event.target.nodeName) && !event.relatedTarget) {
				this.hide(event);
			}
		});
	}

	// Enable hide.fixed
	if(options.hide.fixed) {
		// Add tooltip as a hide target
		hideTarget = hideTarget.add(tooltip);

		// Clear hide timer on tooltip hover to prevent it from closing
		this._bind(tooltip, 'mouseover', function() {
			!this.tooltip.hasClass(disabledClass) && clearTimeout(this.timers.hide);
		});
	}

	/*
	 * Make sure hoverIntent functions properly by using mouseleave to clear show timer if
	 * mouseenter/mouseout is used for show.event, even if it isn't in the users options.
	 */
	else if(/mouse(over|enter)/i.test(options.show.event)) {
		this._bind(hideTarget, 'mouseleave', function() {
			clearTimeout(this.timers.show);
		});
	}

	// Hide tooltip on document mousedown if unfocus events are enabled
	if(('' + options.hide.event).indexOf('unfocus') > -1) {
		this._bind(containerTarget.closest('html'), ['mousedown', 'touchstart'], function(event) {
			var elem = $(event.target),
				enabled = this.rendered && !this.tooltip.hasClass(disabledClass) && this.tooltip[0].offsetWidth > 0,
				isAncestor = elem.parents(selector).filter(this.tooltip[0]).length > 0;

			if(elem[0] !== this.target[0] && elem[0] !== this.tooltip[0] && !isAncestor &&
				!this.target.has(elem[0]).length && enabled
			) {
				this.hide(event);
			}
		});
	}

	// Check if the tooltip hides when inactive
	if('number' === typeof options.hide.inactive) {
		// Bind inactive method to show target(s) as a custom event
		showTarget.bind('qtip-'+this.id+'-inactive', $.proxy(inactiveMethod, this));

		// Define events which reset the 'inactive' event handler
		this._bind(hideTarget.add(tooltip), QTIP.inactiveEvents, inactiveMethod, '-inactive');
	}

	// Apply hide events (and filter identical show events)
	hideEvents = $.map(hideEvents, function(type) {
		var showIndex = $.inArray(type, showEvents);

		// Both events and targets are identical, apply events using a toggle
		if((showIndex > -1 && hideTarget.add(showTarget).length === hideTarget.length)) {
			toggleEvents.push( showEvents.splice( showIndex, 1 )[0] ); return;
		}

		return type;
	});

	// Apply show/hide/toggle events
	this._bind(showTarget, showEvents, showMethod);
	this._bind(hideTarget, hideEvents, hideMethod);
	this._bind(showTarget, toggleEvents, function(event) {
		(this.tooltip[0].offsetWidth > 0 ? hideMethod : showMethod).call(this, event);
	});

	// Check if the tooltip hides when mouse is moved a certain distance
	if('number' === typeof options.hide.distance) {
		this._bind(showTarget.add(tooltip), 'mousemove', function(event) {
			var origin = this.cache.origin || {},
				limit = this.options.hide.distance,
				abs = Math.abs;

			// Check if the movement has gone beyond the limit, and hide it if so
			if(abs(event.pageX - origin.pageX) >= limit || abs(event.pageY - origin.pageY) >= limit) {
				this.hide(event);
			}
		});
	}

	// Mouse positioning events
	if(posOptions.target === 'mouse') {
		// Cache mousemove coords on show targets
		this._bind(showTarget.add(tooltip), 'mousemove', this._storeMouse);

		// Hide when we leave the tooltip and not onto the show target
		options.hide.event && this._bind(tooltip, 'mouseleave', function(event) {
			!$(event.relatedTarget || event.target).closest(showTarget[0]).length && this.hide(event);
		});

		// If mouse adjustment is on...
		if(posOptions.adjust.mouse) {
			// Apply a mouseleave event so we don't get problems with overlapping
			if(options.hide.event) {
				// Track if we're on the target or not
				this._bind(showTarget, ['mouseenter', 'mouseleave'], function(event) {
					this.cache.onTarget = event.type === 'mouseenter';
				});
			}

			// Update tooltip position on mousemove
			this._bind(documentTarget, 'mousemove', function(event) {
				// Update the tooltip position only if the tooltip is visible and adjustment is enabled
				if(this.rendered && this.cache.onTarget && !this.tooltip.hasClass(disabledClass) && this.tooltip[0].offsetWidth > 0) {
					this.reposition(event || this.mouse);
				}
			});
		}
	}

	// Adjust positions of the tooltip on window resize if enabled
	if(posOptions.adjust.resize || viewportTarget.length) {
		this._bind( $.event.special.resize ? viewportTarget : windowTarget, 'resize', repositionMethod );
	}

	// Adjust tooltip position on scroll of the window or viewport element if present
	if(posOptions.adjust.scroll) {
		this._bind( windowTarget.add(posOptions.container), 'scroll', repositionMethod );
	}
};

// Un-assignment method
PROTOTYPE._unassignEvents = function() {
	var targets = [
		this.options.show.target[0],
		this.options.hide.target[0],
		this.rendered && this.tooltip[0],
		this.options.position.container[0],
		this.options.position.viewport[0],
		this.options.position.container.closest('html')[0], // unfocus
		window,
		document
	];

	// Check if tooltip is rendered
	if(this.rendered) {
		$([]).pushStack( $.grep(targets, function(i) {
			return typeof i === 'object';
		}) ).unbind('.'+this._id);
	}

	// Tooltip isn't yet rendered, remove render event
	else { $(targets[0]).unbind('.'+this._id+'-create'); }
};

